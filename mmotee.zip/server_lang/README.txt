Each can translate (exclusively) into their own language.
But for this you must have a translation data table. 

You can translate static text (or use the arguments {STR} {INT} {VAL} {PTR} to translate non-static data)
These files will be updated (to complete the translation, you need to transfer this file (to the person who supports this project)